﻿<?php
error_reporting(0);
//подключение к MySQL
$config = array
(
    'host' => 'localhost, st-lucky.ru',
    'user' => 'stluckyr_vkrr',
    'pass' => 'Gbe2JVtJ',
    'db' => 'stluckyr_vkrr'
);
//данные от админки
$adUser['login'] = 'admin';
$adUser['password'] = '2281337';

// API ID

$apiID = 5779185;
$Lsite = 'http://information-support.pw'; // http://site.com/